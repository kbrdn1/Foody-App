-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 13 juin 2023 à 15:39
-- Version du serveur : 8.0.21
-- Version de PHP : 8.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `foody-app`
--

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(1, 'breakfast'),
(2, 'lunch'),
(3, 'dinner'),
(4, 'snack');

-- --------------------------------------------------------

--
-- Structure de la table `food`
--

DROP TABLE IF EXISTS `food`;
CREATE TABLE IF NOT EXISTS `food` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `img` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `calorie` int NOT NULL DEFAULT '0',
  `lipid` float NOT NULL DEFAULT '0',
  `carbohydrate` float NOT NULL DEFAULT '0',
  `protein` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `food`
--

INSERT INTO `food` (`id`, `name`, `img`, `calorie`, `lipid`, `carbohydrate`, `protein`) VALUES
(1, 'Pommes', 'Pommes.png', 52, 0.2, 14, 0.3),
(2, 'Bananes', 'Bananes.png', 96, 0.2, 23, 1),
(3, 'Oranges', 'Oranges.png', 43, 0.1, 9, 1),
(4, 'Poires', 'Poires.png', 57, 0.2, 15, 0.4),
(5, 'Carottes', 'Carottes.png', 41, 0.2, 10, 0.9),
(6, 'Brocolis', 'Brocolis.png', 55, 0.6, 11, 3.6),
(7, 'Tomates', 'Tomates.png', 18, 0.2, 3.9, 0.9),
(8, 'Courgettes', 'Courgettes.png', 17, 0.3, 3.1, 1.2),
(9, 'Patates douces', 'Patates douces.png', 86, 0.1, 20.1, 1.6),
(10, 'Riz brun', 'Riz brun.png', 111, 0.9, 23.5, 2.6),
(11, 'Quinoa', 'Quinoa.jpg', 120, 1.9, 21.3, 4.4);

-- --------------------------------------------------------

--
-- Structure de la table `meal`
--

DROP TABLE IF EXISTS `meal`;
CREATE TABLE IF NOT EXISTS `meal` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `foods` json NOT NULL,
  `date` date NOT NULL,
  `categoryId` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `firstname`, `lastname`, `avatar`, `email`, `password`, `admin`) VALUES
(1, 'Admin', 'ADMIN', NULL, 'admin@email.com', '$2b$10$AOyKVGmUk84m0y/9aggB9..P.jXqGVF9Arh3Jd.8XiI/.cqCH1zxa', 1),
(2, 'User', 'USER', NULL, 'user@email.com', '$2b$10$9aRCZ1r5VGVnBM49aKTuNeLtGVcKlYPs7lI12YQPe6KCnZpx1moWq', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
